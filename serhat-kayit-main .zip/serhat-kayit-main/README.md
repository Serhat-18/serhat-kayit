# serhat-kayit
✦ A L C H E R A ✦ V1 Kayıt Botu

Yakında burada paylaşılacaktır

Alchera Sunucumuzda kullandığımız v1 kayıt botudur

quick.db database sahiptir

kolay editlenebilmesi açısından herşey configdedir

full + full open source dir

fotoğraf tanıtım vs dc de var

sorunuz vs olursa discorda gelebilirsiniz

yakında daha güzel projelerle...


Destek : https://discord.gg/FQ8bp5jx3H

V2 Kayıt Botu MongoDB kullanmaktadır yakında tanıtımı discordda olacaktır

--------------------------------------------------------------------------------------

Eğer FiveM için kullanacaksanız commands klasöründeki erkek ve kadın.js dosyalarını silin

ardından FiveM adlı klasördeki wl.js dosyasını çıkarıp commands a atın ve configden erkek ve kadın kısımlarını silin ^^



![image](https://cdn.discordapp.com/attachments/846171633240899655/851368297253044234/1.PNG)

![image](https://cdn.discordapp.com/attachments/846171633240899655/851368353498005504/3.PNG)

![image](https://cdn.discordapp.com/attachments/846171633240899655/851368402722488330/2.PNG)

![image](https://cdn.discordapp.com/attachments/846171633240899655/851368450391408640/4.PNG)

![image](https://cdn.discordapp.com/attachments/846171633240899655/851368651436720168/1.PNG)
